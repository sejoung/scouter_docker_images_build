rm -f *.scouter
